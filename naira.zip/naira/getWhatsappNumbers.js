
// var i = document.querySelectorAll('div')
// var word = ''
// var arr = []
// var data = []
// for(x of i){
//     for(y of x.querySelectorAll('span')){
//         word = y.textContent.replaceAll('.', '').replaceAll(' ', '')
//         if(isNaN(Number(word)) == false){
//             if(word.length>9){
//                 if(word!=arr[arr.length-1]){
//                     arr.push(word)
//                     data.push(word)
//                 }
//             }

//         }
//     }
// }

// let csvContent = "data:text/csv;charset=utf-8,";

// data.forEach(function(rowArray) {
//     let row = rowArray.join(",");
//     csvContent += row + "\r\n";
// });